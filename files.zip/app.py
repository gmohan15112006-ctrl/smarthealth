from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import openpyxl
from openpyxl import Workbook
import os, random, smtplib, datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from functools import wraps

app = Flask(__name__)
app.secret_key = 'meditrack-secret-2026'

EXCEL_FILE = 'meditrack_data.xlsx'
ADMIN_EMAIL = 'sanjeevasp2213@gmail.com'

# ---------- Excel helpers ----------

def init_excel():
    """Create Excel file with all sheets if it doesn't exist."""
    if os.path.exists(EXCEL_FILE):
        return
    wb = Workbook()

    # Sheet 1: Patients
    ws = wb.active
    ws.title = 'Patients'
    ws.append(['S.No', 'Name', 'Age', 'Sex', 'Date', 'Department',
               'Category', 'Time Category', 'Pillar Type',
               'Type (Non Pillar)', 'Medico Legal Status', 'Added By'])
    # Sample data
    samples = [
        [1,'Vijaypriya',26,'F','4/1/2026','SURGERY CASES','ASSAULT','12-60','PILLAR','OTHERS','MLC','Dr. Ramesh K'],
        [2,'Karthik R',34,'M','4/1/2026','MEDICINE CASES','CHEST PAIN','>60','NON PILLAR','CHEST PAIN','NMLC','Dr. Anitha S'],
        [3,'Priya M',22,'F','4/2/2026','SURGERY CASES','BURNS','<12-60','PILLAR','','MLC','Dr. Ramesh K'],
        [4,'Anand V',45,'M','4/3/2026','MEDICINE CASES','POISONING','>60','NON PILLAR','OTHERS','MLC','Dr. Ramesh K'],
        [5,'Meena S',31,'F','4/3/2026','SURGERY CASES','FALL','<12-60','PILLAR','','NMLC','Dr. Anitha S'],
    ]
    for row in samples:
        ws.append(row)

    # Sheet 2: Users
    ws2 = wb.create_sheet('Users')
    ws2.append(['User ID','Name','Email','Phone','Role','Verified'])
    ws2.append(['U001','Super Admin', ADMIN_EMAIL,'9000000000','Admin','Yes'])
    ws2.append(['U002','Dr. Ramesh K','doctor.ramesh@hospital.com','9876543210','Doctor','Yes'])
    ws2.append(['U003','Dr. Anitha S','doctor.anitha@hospital.com','9876543211','Doctor','Yes'])
    ws2.append(['U004','Vijaypriya','vijaypriya@gmail.com','9123456789','Patient','Yes'])

    # Sheet 3: Audit Log
    ws3 = wb.create_sheet('Audit Log')
    ws3.append(['Timestamp','User','Role','Action','Record'])

    wb.save(EXCEL_FILE)

def get_workbook():
    init_excel()
    return openpyxl.load_workbook(EXCEL_FILE)

def get_all_patients():
    wb = get_workbook()
    ws = wb['Patients']
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0]:
            rows.append({
                'no': row[0], 'name': row[1], 'age': row[2], 'sex': row[3],
                'date': row[4], 'dept': row[5], 'cat': row[6], 'time': row[7],
                'pillar': row[8], 'nptype': row[9] or '', 'status': row[10],
                'added_by': row[11] or ''
            })
    return rows

def add_patient(data, added_by):
    wb = get_workbook()
    ws = wb['Patients']
    next_no = ws.max_row  # header is row 1, so max_row gives next s.no
    ws.append([
        next_no, data['name'], int(data['age']), data['sex'],
        data['date'], data['dept'], data['cat'], data['time'],
        data['pillar'], data.get('nptype', ''), data['status'], added_by
    ])
    log_audit(wb, added_by, session.get('role',''), 'Added record',
              f"{data['name']}, {data['dept']}")
    wb.save(EXCEL_FILE)
    return next_no

def update_patient(sno, data):
    wb = get_workbook()
    ws = wb['Patients']
    for row in ws.iter_rows(min_row=2):
        if row[0].value == sno:
            row[1].value = data['name']
            row[2].value = int(data['age'])
            row[3].value = data['sex']
            row[4].value = data['date']
            row[5].value = data['dept']
            row[6].value = data['cat']
            row[7].value = data['time']
            row[8].value = data['pillar']
            row[9].value = data.get('nptype', '')
            row[10].value = data['status']
            break
    log_audit(wb, session.get('name','Admin'), 'Admin', 'Edited record', f"S.No {sno}")
    wb.save(EXCEL_FILE)

def delete_patient(sno):
    wb = get_workbook()
    ws = wb['Patients']
    for row in ws.iter_rows(min_row=2):
        if row[0].value == sno:
            ws.delete_rows(row[0].row)
            break
    log_audit(wb, session.get('name','Admin'), 'Admin', 'Deleted record', f"S.No {sno}")
    wb.save(EXCEL_FILE)

def get_users():
    wb = get_workbook()
    ws = wb['Users']
    users = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0]:
            users.append({'id': row[0], 'name': row[1], 'email': row[2],
                          'phone': row[3], 'role': row[4], 'verified': row[5]})
    return users

def find_user_by_email(email):
    for u in get_users():
        if u['email'].lower() == email.lower():
            return u
    return None

def log_audit(wb, user, role, action, record):
    ws = wb['Audit Log']
    ts = datetime.datetime.now().strftime('%d/%m/%Y %H:%M')
    ws.append([ts, user, role, action, record])

def get_audit_log():
    wb = get_workbook()
    ws = wb['Audit Log']
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0]:
            rows.append({'ts': row[0], 'user': row[1], 'role': row[2],
                         'action': row[3], 'record': row[4]})
    return list(reversed(rows))

# ---------- OTP store (in-memory for demo) ----------
otp_store = {}  # email -> otp

def generate_otp(email):
    otp = str(random.randint(100000, 999999))
    otp_store[email.lower()] = otp
    return otp

def verify_otp(email, otp):
    return otp_store.get(email.lower()) == otp

# ---------- Email sender ----------
def send_otp_email(to_email, otp, name='User'):
    """Send OTP via Gmail SMTP. Configure credentials in config.py."""
    try:
        sender = os.environ.get('GMAIL_USER', '')
        password = os.environ.get('GMAIL_PASS', '')
        if not sender or not password:
            print(f"[DEV MODE] OTP for {to_email}: {otp}")
            return True  # dev mode — print to console
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = to_email
        msg['Subject'] = 'MediTrack — Your OTP'
        body = f"Hello {name},\n\nYour OTP for MediTrack login is: {otp}\n\nThis OTP expires in 10 minutes.\n\nMediTrack System"
        msg.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender, password)
        server.sendmail(sender, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

def notify_admin(doctor_name, patient_name, dept):
    """Notify admin when a doctor adds a patient record."""
    try:
        sender = os.environ.get('GMAIL_USER', '')
        password = os.environ.get('GMAIL_PASS', '')
        if not sender or not password:
            print(f"[DEV MODE] Admin notified: {doctor_name} added {patient_name}")
            return
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = ADMIN_EMAIL
        msg['Subject'] = 'MediTrack — New Patient Record Added'
        body = f"New patient record added by {doctor_name}.\nPatient: {patient_name}\nDepartment: {dept}\n\nLogin to MediTrack to view details."
        msg.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender, password)
        server.sendmail(sender, ADMIN_EMAIL, msg.as_string())
        server.quit()
    except Exception as e:
        print(f"Notify admin error: {e}")

# ---------- Auth decorators ----------
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'email' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if session.get('role') not in roles:
                flash('Access denied.', 'error')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated
    return decorator

# ---------- Routes ----------

@app.route('/')
def index():
    if 'email' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        user = find_user_by_email(email)
        if not user:
            flash('Email not registered.', 'error')
            return render_template('login.html')
        if user['verified'] != 'Yes':
            flash('Account not verified. Contact admin.', 'error')
            return render_template('login.html')
        otp = generate_otp(email)
        send_otp_email(email, otp, user['name'])
        session['pending_email'] = email
        flash(f'OTP sent to {email}. (Dev mode: check console)', 'info')
        return render_template('login.html', show_otp=True, email=email)
    return render_template('login.html')

@app.route('/verify-otp', methods=['POST'])
def verify_otp_route():
    email = request.form.get('email', '').strip()
    otp = request.form.get('otp', '').strip()
    if not verify_otp(email, otp):
        flash('Invalid OTP. Please try again.', 'error')
        return render_template('login.html', show_otp=True, email=email)
    user = find_user_by_email(email)
    session['email'] = email
    session['name'] = user['name']
    session['role'] = user['role']
    session['user_id'] = user['id']
    otp_store.pop(email.lower(), None)
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    role = session.get('role')
    if role == 'Admin':
        return redirect(url_for('admin_dashboard'))
    elif role == 'Doctor':
        return redirect(url_for('doctor_dashboard'))
    elif role == 'Patient':
        return redirect(url_for('patient_dashboard'))
    return redirect(url_for('login'))

# ----- Admin routes -----

@app.route('/admin')
@login_required
@role_required('Admin')
def admin_dashboard():
    patients = get_all_patients()
    stats = {
        'total': len(patients),
        'mlc': sum(1 for p in patients if p['status'] == 'MLC'),
        'surgery': sum(1 for p in patients if 'SURGERY' in (p['dept'] or '')),
        'medicine': sum(1 for p in patients if 'MEDICINE' in (p['dept'] or '')),
    }
    return render_template('admin_dashboard.html', patients=patients[-5:], stats=stats)

@app.route('/admin/patients')
@login_required
@role_required('Admin')
def admin_patients():
    patients = get_all_patients()
    return render_template('admin_patients.html', patients=patients)

@app.route('/admin/edit/<int:sno>', methods=['GET', 'POST'])
@login_required
@role_required('Admin')
def admin_edit(sno):
    patients = get_all_patients()
    patient = next((p for p in patients if p['no'] == sno), None)
    if not patient:
        flash('Record not found.', 'error')
        return redirect(url_for('admin_patients'))
    if request.method == 'POST':
        update_patient(sno, request.form)
        flash('Record updated successfully.', 'success')
        return redirect(url_for('admin_patients'))
    return render_template('edit_patient.html', patient=patient)

@app.route('/admin/delete/<int:sno>', methods=['POST'])
@login_required
@role_required('Admin')
def admin_delete(sno):
    delete_patient(sno)
    flash('Record deleted.', 'success')
    return redirect(url_for('admin_patients'))

@app.route('/admin/audit')
@login_required
@role_required('Admin')
def admin_audit():
    logs = get_audit_log()
    return render_template('audit_log.html', logs=logs)

@app.route('/admin/export')
@login_required
@role_required('Admin')
def admin_export():
    from flask import send_file
    init_excel()
    return send_file(EXCEL_FILE, as_attachment=True,
                     download_name='meditrack_export.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

# ----- Doctor routes -----

@app.route('/doctor')
@login_required
@role_required('Doctor')
def doctor_dashboard():
    all_p = get_all_patients()
    my_records = [p for p in all_p if p.get('added_by') == session['name']]
    return render_template('doctor_dashboard.html', records=my_records)

@app.route('/doctor/add', methods=['GET', 'POST'])
@login_required
@role_required('Doctor')
def doctor_add():
    if request.method == 'POST':
        add_patient(request.form, session['name'])
        notify_admin(session['name'], request.form.get('name'), request.form.get('dept'))
        flash('Patient record added successfully. Admin has been notified.', 'success')
        return redirect(url_for('doctor_dashboard'))
    return render_template('doctor_add.html')

# ----- Patient routes -----

@app.route('/patient')
@login_required
@role_required('Patient')
def patient_dashboard():
    all_p = get_all_patients()
    # Match by name (simple demo approach)
    my_record = next((p for p in all_p if p['name'].lower() in session['name'].lower()
                      or session['name'].lower() in p['name'].lower()), None)
    return render_template('patient_dashboard.html', record=my_record)

if __name__ == '__main__':
    init_excel()
    app.run(debug=True)
