# MediTrack — Smart Doctor–Patient Management System

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. (Optional) Configure Gmail OTP
Set environment variables for real email sending:
```bash
# Windows
set GMAIL_USER=your_gmail@gmail.com
set GMAIL_PASS=your_app_password

# Linux / Mac
export GMAIL_USER=your_gmail@gmail.com
export GMAIL_PASS=your_app_password
```
> Without these, OTP prints to the terminal console (dev mode).
> Gmail requires an App Password (not your normal password).
> Enable at: https://myaccount.google.com/apppasswords

### 3. Run the app
```bash
python app.py
```
Visit: http://127.0.0.1:5000

---

## Demo accounts

| Role    | Email                          | OTP (dev)  |
|---------|-------------------------------|------------|
| Admin   | sanjeevasp2213@gmail.com      | see console|
| Doctor  | doctor.ramesh@hospital.com    | see console|
| Doctor  | doctor.anitha@hospital.com    | see console|
| Patient | vijaypriya@gmail.com          | see console|

---

## File structure

```
meditrack/
├── app.py                  # Main Flask app + all routes
├── meditrack_data.xlsx     # Auto-created Excel database
├── requirements.txt
├── README.md
└── templates/
    ├── base.html           # Layout, topbar, sidebar CSS
    ├── login.html          # Login + OTP verification
    ├── admin_dashboard.html
    ├── admin_patients.html # Full table with edit/delete
    ├── edit_patient.html
    ├── audit_log.html
    ├── doctor_dashboard.html  # View own records
    ├── doctor_add.html        # Add patient form
    └── patient_dashboard.html # Read-only view
```

---

## Excel database sheets

| Sheet         | Columns                                                         |
|---------------|-----------------------------------------------------------------|
| Patients      | S.No, Name, Age, Sex, Date, Department, Category, Time Category, Pillar Type, Type (Non Pillar), Medico Legal Status, Added By |
| Users         | User ID, Name, Email, Phone, Role, Verified                     |
| Audit Log     | Timestamp, User, Role, Action, Record                           |

---

## Role permissions

| Feature              | Admin | Doctor | Patient |
|----------------------|-------|--------|---------|
| View all records     | ✓     | ✗      | ✗       |
| Edit records         | ✓     | ✗      | ✗       |
| Delete records       | ✓     | ✗      | ✗       |
| Add patient          | ✓     | ✓      | ✗       |
| View own records     | ✓     | ✓      | ✗       |
| View own profile     | ✓     | ✗      | ✓       |
| Export Excel         | ✓     | ✗      | ✗       |
| View audit log       | ✓     | ✗      | ✗       |
